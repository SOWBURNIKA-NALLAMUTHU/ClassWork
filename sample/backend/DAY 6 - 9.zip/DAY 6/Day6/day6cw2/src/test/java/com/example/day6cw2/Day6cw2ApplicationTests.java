package com.example.day6cw2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day6cw2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
