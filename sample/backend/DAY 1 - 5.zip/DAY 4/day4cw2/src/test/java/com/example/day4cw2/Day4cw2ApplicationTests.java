package com.example.day4cw2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day4cw2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
